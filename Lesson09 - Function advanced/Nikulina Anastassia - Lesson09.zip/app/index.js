const wrap = function (value, depth) {
    const obj = {};
    obj.someKey = depth <= 0 ? value : wrap(value, depth - 1);
    return obj;
}
const unwrap = function (target, key) {
    const tempResult = target[key];
    if (typeof tempResult === "object") {
        return unwrap(tempResult, key);
    } else {
        return tempResult;
    }
}

const randomInt = getRandomInt(5, 10);
const wrappedObj = wrap("hello", randomInt);
const result = unwrap(wrappedObj, "someKey");

console.log(wrappedObj);
console.log(result);


function getRandomInt(min, max) {
    min = Math.ceil(min);
    max = Math.floor(max);

    return Math.floor(Math.random() * (max - min + 1) + min);
};
