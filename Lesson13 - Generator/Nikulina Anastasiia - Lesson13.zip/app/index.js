const currentYear = new Date;

const isLeapYear = (year) => {
    return year % 400 === 0 || (year % 100 !== 0 && year % 4 === 0);
}

function* leapYears() {
    for (let y = 1900; y <= currentYear.getFullYear(); y++) {
        if (isLeapYear(y)) {
            yield y;
        }
    }
}

const yearsGenerator = leapYears();

let isNotDone = true;
do {
    const current = yearsGenerator.next();
    isNotDone = !current.done;
    console.log(current);
} while (isNotDone)

console.log("------------------")

let count1 = 1;
let sum = 0;

function* counter() {

    while (true) {

        let temp = yield sum;
        if (!isNaN(temp)) {
            count1 = temp;
        }
        sum = sum + count1;
    }

}


const count = counter();

console.log(count.next()); // {value: 0, done: false}
console.log(count.next()); // {value: 1, done: false}
console.log(count.next(10)); // {value: 11, done: false}
console.log(count.next()); // {value: 21, done: false}
console.log(count.next()); // {value: 31, done: false}
console.log(count.next(100)); // {value: 131, done: false} 


console.log("------------------")


const isEven = (digit) => {
    return digit % 2 === 0;
}

function* evens() {
    for (let y = 2; y <= 100; y++) {
        if (isEven(y)) {
            yield y;
        }
    }
}

const even = evens();

console.log(even.next());
console.log(even.next());
console.log(even.next());
console.log(even.next());

console.log("------------------")

function getRandomIntInclusive(min, max) {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min + 1) + min);
}

function* randomEvens() {
    while (true) {
        let evenArray = new Array();
        let maxCount = getRandomIntInclusive(1, 20);
        let even2 = evens();
        for (let i = 0; i < maxCount; i++) {
            evenArray.push(even2.next().value);
        }
        yield evenArray;
    }

}

const evens2 = randomEvens();
console.log(evens2.next());
console.log(evens2.next());
console.log(evens2.next());